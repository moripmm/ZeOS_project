#include <libc.h>

char buff[24];

int pid;
int m;

void prova_mutex(int p) {
  int vector_size = 100;
  int time_delay = 100000;
  int v[vector_size];
  mutex_lock(&m);
  if (p==0) {
    write(1, "Soy P1\n", 7);
    for (int delay = 0; delay < time_delay; ++delay)
    for (int i = 0; i < vector_size; ++i) 
      v[i] = i;
    write(1, "P1 done\n", 8);
  } else {
    write(1, "Soy P2\n", 7);
    for (int delay = 0; delay < time_delay; ++delay)
    for (int i = 0; i < vector_size; ++i)
      v[i]--;
    write(1, "P2 done\n", 8);
  }
  mutex_unlock(&m);
}

void hola(int i) 
{
  write(1, "hola :)\n", 8);
}

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */
  mutex_init(&m);
  create_thread(prova_mutex, 1);
  prova_mutex(0);
  while(1) {}
}
